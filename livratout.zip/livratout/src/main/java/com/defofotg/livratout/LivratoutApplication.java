package com.defofotg.livratout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivratoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivratoutApplication.class, args);
	}
}
